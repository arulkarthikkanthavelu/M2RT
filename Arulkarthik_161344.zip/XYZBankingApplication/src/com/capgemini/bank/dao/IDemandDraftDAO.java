package com.capgemini.bank.dao;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;

public interface IDemandDraftDAO 
{
	public String addDraftDetails(DemandDraft demanddraftbean) throws DemandDraftException;
	public DemandDraft viewDraftDetails(String transaction_id) throws DemandDraftException;
}
