package com.capgemini.bank.exception;

public class DemandDraftException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DemandDraftException(String message) 
	{
		super(message);
	}

}
